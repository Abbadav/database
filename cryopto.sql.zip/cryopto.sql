-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2021 at 11:00 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cryopto`
--

-- --------------------------------------------------------

--
-- Table structure for table `cashflow`
--

CREATE TABLE `cashflow` (
  `cfid` int(11) NOT NULL,
  `pair` varchar(30) DEFAULT NULL,
  `cashFlow` varchar(30) DEFAULT NULL,
  `cashVol` varchar(30) DEFAULT NULL,
  `price` varchar(30) DEFAULT NULL,
  `gvupdate` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cashflow`
--

INSERT INTO `cashflow` (`cfid`, `pair`, `cashFlow`, `cashVol`, `price`, `gvupdate`) VALUES
(1, 'John Daniel', 'high', '24%', '3900', '7500'),
(2, 'Wilson Adams', 'low', '35%', '500', '800'),
(3, 'Jimmy Adoke', 'medium', '45%', '3400', '5500'),
(4, 'Favour Kalu', 'high', '75%', '800', '5000'),
(5, 'Hycent Goodluck', 'low', '75%', '3000', '5000'),
(6, 'Jonah John', 'medium', '65%', '3500', '5500'),
(7, 'Benson Iddia', 'high', '42%', '3300', '6500'),
(8, 'John Dennis', 'high', '24%', '300', '500'),
(9, 'John Jude', 'high', '94%', '300', '500'),
(10, 'John James', 'high', '24%', '300', '500');

-- --------------------------------------------------------

--
-- Table structure for table `customerdeals`
--

CREATE TABLE `customerdeals` (
  `cuid` int(11) NOT NULL,
  `revtime` varchar(20) DEFAULT NULL,
  `referral` varchar(30) DEFAULT NULL,
  `avetime` varchar(30) DEFAULT NULL,
  `totaltime` varchar(30) DEFAULT NULL,
  `fullName` varchar(30) DEFAULT NULL,
  `contactNo` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customerdeals`
--

INSERT INTO `customerdeals` (`cuid`, `revtime`, `referral`, `avetime`, `totaltime`, `fullName`, `contactNo`) VALUES
(1, 'DOD', 'michael', '2', '7', 'Joseph Odoh', '08067389743'),
(2, 'BOS', 'Belema', '3', '8', 'Grace Ani', '08067376453'),
(3, 'Ded', 'grace', '2', '7', 'adebajo Olu', '0807869743');

-- --------------------------------------------------------

--
-- Table structure for table `customerdtial`
--

CREATE TABLE `customerdtial` (
  `cdid` int(11) NOT NULL,
  `fullName` varchar(50) DEFAULT NULL,
  `rgNo` int(11) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `DOB` varchar(30) DEFAULT NULL,
  `applicantProve` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customerdtial`
--

INSERT INTO `customerdtial` (`cdid`, `fullName`, `rgNo`, `gender`, `DOB`, `applicantProve`) VALUES
(1, 'Blessig Ujah', 0, 'female', '34', 'cash'),
(2, 'Richmond Nweke', 0, 'male', '33', 'cash'),
(3, 'Adeolu Kayode', 0, 'male', '23', 'transfer'),
(6, 'Loveth Ufunaya', 0, 'female', '30', 'cash'),
(7, 'Confidence Chukwu', 0, 'male', '43', 'transfer'),
(8, 'Dele Momodu', 0, 'male', '63', 'cash'),
(11, 'Nneka Nweke', 0, 'female', '34', 'dollar'),
(12, 'Agnes Obi', 0, 'female', '32', 'transfer'),
(21, 'Dele Ojo', 0, 'male', '86', 'transfer'),
(23, 'Vivian Eke', 0, 'male', '33', 'cash');

-- --------------------------------------------------------

--
-- Table structure for table `customertransaction`
--

CREATE TABLE `customertransaction` (
  `ctid` int(11) NOT NULL,
  `modeOfPayment` varchar(30) DEFAULT NULL,
  `paydate` date DEFAULT NULL,
  `cashOrTran` varchar(30) DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `timeOfpay` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customertransaction`
--

INSERT INTO `customertransaction` (`ctid`, `modeOfPayment`, `paydate`, `cashOrTran`, `duedate`, `timeOfpay`) VALUES
(101, 'naira', '0000-00-00', 'cash', '0000-00-00', '03:40'),
(102, 'dollars', '0000-00-00', 'transfer', '0000-00-00', '17:40'),
(103, 'naira', '0000-00-00', 'cash', '0000-00-00', '13:40'),
(104, 'naira', '0000-00-00', 'dollars', '0000-00-00', '09:40'),
(105, 'naira', '0000-00-00', 'transfer', '0000-00-00', '09:40'),
(106, 'bitcoin', '0000-00-00', 'transfer', '0000-00-00', '11:40'),
(107, 'naira', '0000-00-00', 'cash', '0000-00-00', '00:40'),
(108, 'bitcoin', '0000-00-00', 'trasfer', '0000-00-00', '07:40'),
(109, 'naira', '0000-00-00', 'cash', '0000-00-00', '02:40'),
(110, 'naira', '0000-00-00', 'cash', '0000-00-00', '03:40'),
(111, 'naira', '0000-00-00', 'cash', '0000-00-00', '03:40'),
(112, 'dollars', '0000-00-00', 'transfer', '0000-00-00', '17:40'),
(113, 'naira', '0000-00-00', 'cash', '0000-00-00', '13:40'),
(114, 'naira', '0000-00-00', 'dollars', '0000-00-00', '09:40'),
(115, 'naira', '0000-00-00', 'transfer', '0000-00-00', '09:40'),
(116, 'bitcoin', '0000-00-00', 'transfer', '0000-00-00', '11:40'),
(117, 'naira', '0000-00-00', 'cash', '0000-00-00', '00:40'),
(118, 'bitcoin', '0000-00-00', 'trasfer', '0000-00-00', '07:40'),
(119, 'naira', '0000-00-00', 'cash', '0000-00-00', '02:40'),
(120, 'naira', '0000-00-00', 'cash', '0000-00-00', '03:40');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `rid` int(11) NOT NULL,
  `userName` varchar(30) DEFAULT NULL,
  `upwd` varchar(30) DEFAULT NULL,
  `rpwd` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`rid`, `userName`, `upwd`, `rpwd`) VALUES
(1, 'blesses', 'hood12', 'hood12'),
(2, 'iworibo', '094iwori', '094iwori'),
(3, 'Tobesi', 'tope123', 'tope123'),
(4, 'teacher', 'techme', 'teachme'),
(5, 'abbbad', 'abbalo', 'abbalo'),
(6, 'cofidence', 'confi', 'confi'),
(7, 'richy', 'rich', 'rich'),
(8, 'mychoice', 'choice', 'choice'),
(9, 'loveth', 'love', 'love'),
(10, 'tunde', 'tun12', 'tun12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cashflow`
--
ALTER TABLE `cashflow`
  ADD PRIMARY KEY (`cfid`);

--
-- Indexes for table `customerdeals`
--
ALTER TABLE `customerdeals`
  ADD PRIMARY KEY (`cuid`);

--
-- Indexes for table `customerdtial`
--
ALTER TABLE `customerdtial`
  ADD PRIMARY KEY (`cdid`);

--
-- Indexes for table `customertransaction`
--
ALTER TABLE `customertransaction`
  ADD PRIMARY KEY (`ctid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`rid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cashflow`
--
ALTER TABLE `cashflow`
  MODIFY `cfid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `customerdeals`
--
ALTER TABLE `customerdeals`
  MODIFY `cuid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customerdtial`
--
ALTER TABLE `customerdtial`
  MODIFY `cdid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `customertransaction`
--
ALTER TABLE `customertransaction`
  MODIFY `ctid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
